local M = {}

function M.shoot(api)
    api:shootOnce(false)
end

return M